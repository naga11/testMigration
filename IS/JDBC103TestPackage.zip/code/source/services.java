

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
// --- <<IS-END-IMPORTS>> ---

public final class services

{
	// ---( internal utility methods )---

	final static services _instance = new services();

	static services _newInstance() { return new services(); }

	static services _cast(Object o) { return (services)o; }

	// ---( server methods )---




	public static final void array (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(array)>> ---
		// @sigtype java 3.5
		// [o] object:0:required out
		String tests = "560037";
		ValuesEmulator.put(pipeline, "out", tests.getBytes());
		// --- <<IS-END>> ---

                
	}
}

